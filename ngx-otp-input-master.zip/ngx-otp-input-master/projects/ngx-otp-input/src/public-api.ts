/*
 * Public API Surface of ngx-otp-input
 */

export * from './lib/component/ngx-otp-input.component';
export * from './lib/component/ngx-otp-input.model';
export * from './lib/ngx-otp-input.module';
