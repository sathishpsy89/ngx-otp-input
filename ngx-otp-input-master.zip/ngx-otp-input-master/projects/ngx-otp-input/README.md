**ngx-otp-input** is a simple one time password input library for Angular. For more information, please visit this [site](https://github.com/pkovzz/ngx-otp-input).
